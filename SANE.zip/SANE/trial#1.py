import speech_recognition as sr
from time import ctime
import webbrowser
import os
from gtts import gTTS
import pyaudio
from playsound import playsound
 
def talktome(audio):
    print(audio)
    tts=gTTS(text=audio, lang='en')
    tts.save('audio.mp3')
    playsound('audio.mp3')

#listens to commands

def myCommand():
    r=sr.Recognizer()
    r.energy_threshold=4000
    with sr.Microphone() as source:
        print("I am ready for the next command")
        r.pause_threshold=1
        r.adjust_for_ambient_noise(source, duration=1)
        audio=r.listen(source)
    try:
        command=r.recognize_google(audio)
        print("You said " + command)

    except sr.UnknownValueError:
        assistant(myCommand())
    return command

def assistant(command):
    if 'open google' in command:
        chrome_path="C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
        url='www.google.com'
        webbrowser.get(chrome_path).open(url)

    if 'what are you doing' in command:
        talktome("Nothing much")

talktome("I am ready for your command")

while True:
    assistant(myCommand())
