from splinter import Browser

browser=Browser('chrome')
url="https://www.google.com/maps"
browser.visit(url)
browser.fill('q', 'palam vihar')
#browser.find_by_name('btnK').first.click()
